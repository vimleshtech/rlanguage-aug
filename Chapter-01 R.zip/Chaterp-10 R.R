
#declare the variables
a <- 11
b <- 11.444
name <- "nitin"

##typeof() is function which return data type
typeof(a)  #show data type   : double
typeof(b) #: double
typeof(name) #character

#validate data type : return boolean value 
is.numeric(a)
is.numeric(b)
is.numeric(name)
is.character(name)

#convert data type 
a <- "11"  #character
b <- "110" #character
is.numeric(a)
is.numeric(b)

a = as.numeric(a)
b = as.numeric(b)

#Arithmetic operation 
c =a+b
print(c)

##literals or keywords (system defined word)
letters
LETTERS
month.name
help()

###Input and output
#output
print('hi')
print("hi")

#input
a = readline(prompt = "enter data ")  #default input type is character
b = readline(prompt = "enter data ")

print(a)
print(b)

as.numeric(a) + as.numeric(b)

x = 100

#Condition 
a = 100 
b =440
#is a is greater than b or not
if(a>b){
  
  print("a is greater than b")
  
}else{
  
  print("b is greater than a")
  
}

#### WAP to show greater number from three input
a =11
b =440
c =55
if(a>b && a>c){
  
  print("a is greater")
  
}else if (b>a && b>c){
  
  print("b is greater")
  
}else{
  print("c is greater")
  
}














